from yellowbrick.regressor import PredictionError

import database_data_importer as dbi
# 1. Building the model of SITE_RUN
x = dbi.x
y = dbi.y
def SITE_RUN(x,y):
    from sklearn.model_selection import train_test_split
    return train_test_split(x, y, test_size=0.2, random_state=123456)

def model_SITE_RUN(x_train, y_train):
    from sklearn.neighbors import KNeighborsRegressor
    regression = KNeighborsRegressor()
    return regression.fit(x_train, y_train)

def cross_validate_SITE_RUN(algorithm, regression, x_test, y_test):
    predictions = regression.predict(x_test)
    return predictions

def visualization_error_SITE_RUN(algorithm, regression, x_test, y_test):
    visualizer = PredictionError(regression)
    visualizer.fit(x_test, y_train)
    visualizer.score(x_test, y_test)
    return visualizer.show()

# # # 1.a SITE_RUN_MODEL
x_train, x_test, y_train, y_test = SITE_RUN(x,y)
# print(y_test)
# print("Model is model_SITE_RUN")
# regressor_SITE_RUN = model_SITE_RUN(x_train, y_train)
# SITE_RUN_prediction_SITE_RUN = cross_validate_SITE_RUN('SITE_RUN', regressor_SITE_RUN, x_test, y_test)
# print(SITE_RUN_prediction_SITE_RUN)
# SITE_RUN_visualization = visualization_error_SITE_RUN('SITE_RUN', regressor_SITE_RUN, x_test, y_test)