from yellowbrick.regressor import PredictionError

import database_data_importer as dbi
# 1. Building the model of SITE_RUN
x = dbi.x
h = dbi.h

def START_EB_KWH(x,h):
    from sklearn.model_selection import train_test_split
    return train_test_split(x, h, test_size=0.2, random_state=123456)

def model_START_EB_KWH(x_train,h_train):
    from sklearn.neighbors import KNeighborsRegressor
    regression = KNeighborsRegressor()
    return regression.fit(x_train, h_train)

def cross_validate_START_EB_KWH(algorithm, regression, x_test, h_test):
    predictions = regression.predict(x_test)
    return predictions

def visualization_error_START_EB_KWH(algorithm, regression, x_test, h_test):
    visualizer = PredictionError(regression)
    visualizer.fit(x_test, h_train)
    visualizer.score(x_test, h_test)
    return visualizer.show()

## 10.a START_DG_KWH_MODEL
x_train, x_test, h_train, h_test = START_EB_KWH(x,h)
