from yellowbrick.regressor import PredictionError

import database_data_importer as dbi
# 1. Building the model of SITE_RUN
x = dbi.x
b = dbi.b

def START_EB_RUN(x,b):
    from sklearn.model_selection import train_test_split
    return train_test_split(x, b, test_size=0.2, random_state=123456)

def model_START_EB_RUN(x_train, b_train):
    from sklearn.neighbors import KNeighborsRegressor
    regression = KNeighborsRegressor()
    return regression.fit(x_train, b_train)

def cross_validate_START_EB_RUN(algorithm, regression, x_test, b_test):
    predictions = regression.predict(x_test)
    return predictions

def visualization_error_START_EB_RUN(algorithm, regression, x_test, b_test):
    visualizer = PredictionError(regression)
    visualizer.fit(x_test, b_train)
    visualizer.score(x_test, b_test)
    return visualizer.show()

## 4.a START_EB_RUN_Model
x_train, x_test, b_train, b_test = START_EB_RUN(x,b)