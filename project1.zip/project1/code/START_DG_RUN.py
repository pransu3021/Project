from yellowbrick.regressor import PredictionError

import database_data_importer as dbi
# 1. Building the model of SITE_RUN
x = dbi.x
z = dbi.z
def START_DG_RUN(x,z):
    from sklearn.model_selection import train_test_split
    return train_test_split(x, z, test_size=0.2, random_state=123456)

def model_START_DG_RUN(x_train, z_train):
    from sklearn.neighbors import KNeighborsRegressor
    regression = KNeighborsRegressor()
    return regression.fit(x_train, z_train)

def cross_validate_START_DG_RUN(algorithm, regression, x_test, z_test):
    predictions = regression.predict(x_test)
    return predictions

def visualization_error_START_DG_RUN(algorithm, regression, x_test, z_test):
    visualizer = PredictionError(regression)
    visualizer.fit(x_test, z_train)
    visualizer.score(x_test, z_test)
    return visualizer.show()


## 2.a START_DG_RUN_MODEL
x_train, x_test, z_train, z_test = START_DG_RUN(x,z)
# print(z_test)
# print("Model is model_START_DG_RUN")
# regressor_START_DG_RUN = model_START_DG_RUN(x_train, z_train)
# START_DG_RUN_prediction_START_DG_RUN = cross_validate_START_DG_RUN('START_DG_RUN', regressor_START_DG_RUN, x_test, z_test)
# print(START_DG_RUN_prediction_START_DG_RUN)
# START_DG_RUN_visualization = visualization_error_START_DG_RUN('START_DG_RUN', regressor_START_DG_RUN, x_test, z_test)
