from datetime import date, datetime

from flask import Flask, request, render_template
import prediction as ml
import numpy as np
import pandas as pd
from flask import Flask, request, jsonify

import mysql.connector
from datetime import date

app = Flask(__name__)

@app.route('/')
def root():
    return render_template('index.html')


@app.route('/predict', methods=["POST"])
def predict():
    db = mysql.connector.connect(host='localhost',
                                 database='project',
                                 user='cdac_project',
                                 password='cdac_project')
    cur = db.cursor()

    print("database connected")
    infraid = request.form['infraid']
    print(infraid)
    cur.execute(f"select Circle_value, Zonne_Value, Cluster_value, INFRATELID_VALUE, BILLING_OPCO_Value, SITE_TYPE_AS_PER_RFI_Value from Web_Page WHERE INFRATELID = '{infraid}'")

    for val in cur:
        Circle = val[0]
        print(Circle)
        Zone = val[1]
        print(Zone)
        Cluster = val[2]
        print(Cluster)
        Infraid = val[3]
        print(Infraid)
        BILLING_OPCO = val[4]
        print(BILLING_OPCO)
        SITE_TYPE_AS_PER_RFI = val[5]
        print(SITE_TYPE_AS_PER_RFI)
    cur.close()
    db.close()
    # MONTH = int(request.form['MONTH'])
    START_DATE = request.form['START_DATE']
    print(START_DATE)
    END_DATE = request.form['END_DATE']
    date_format = "%Y-%m-%d"
    END_DATE = datetime.strptime(END_DATE, date_format)
    START_DATE = datetime.strptime(START_DATE, date_format)
    delta = (END_DATE - START_DATE).days
    print (delta)
    result = dict()

    # Site_run_prediction
    prediction = ml.regressor_SITE_RUN.predict([[Infraid, Circle, Cluster, Zone, BILLING_OPCO, SITE_TYPE_AS_PER_RFI, delta]])
    # prediction = ml.regressor_SITE_RUN.predict([INFRATELID, CIRCLE, CLUSTER, ZONE, BILLING_OPCO, Site_TYPE,MONTH,delta])
    print(prediction)
    result['SITE_RUN'] = prediction

    # regressor_START_DG_RUN
    prediction = ml.regressor_START_DG_RUN.predict([[Infraid, Circle, Cluster, Zone, BILLING_OPCO, SITE_TYPE_AS_PER_RFI, delta]])
    # prediction = ml.regressor_SITE_RUN.predict([INFRATELID, CIRCLE, CLUSTER, ZONE, BILLING_OPCO, Site_TYPE,MONTH,delta])
    print(prediction)
    result['START_DG_RUN'] = prediction

    # regressor_END_DG_RUN
    prediction = ml.regressor_END_DG_RUN.predict([[Infraid, Circle, Cluster, Zone, BILLING_OPCO, SITE_TYPE_AS_PER_RFI, delta]])
    # prediction = ml.regressor_SITE_RUN.predict([INFRATELID, CIRCLE, CLUSTER, ZONE, BILLING_OPCO, Site_TYPE,MONTH,delta])
    print(prediction)
    result['END_DG_RUN'] = prediction

    # regressor_START_EB_RUN
    prediction = ml.regressor_START_EB_RUN.predict(
        [[Infraid, Circle, Cluster, Zone, BILLING_OPCO, SITE_TYPE_AS_PER_RFI, delta]])
    # prediction = ml.regressor_SITE_RUN.predict([INFRATELID, CIRCLE, CLUSTER, ZONE, BILLING_OPCO, Site_TYPE,MONTH,delta])
    print(prediction)
    result['START_EB_RUN'] = prediction

    # regressor_END_EB_RUN
    prediction = ml.regressor_END_EB_RUN.predict([[Infraid, Circle, Cluster, Zone, BILLING_OPCO, SITE_TYPE_AS_PER_RFI, delta]])
    # prediction = ml.regressor_SITE_RUN.predict([INFRATELID, CIRCLE, CLUSTER, ZONE, BILLING_OPCO, Site_TYPE,MONTH,delta])
    print(prediction)
    result['END_EB_RUN'] = prediction

    # regressor_START_BB_RUN
    prediction = ml.regressor_START_BB_RUN.predict(
        [[Infraid, Circle, Cluster, Zone, BILLING_OPCO, SITE_TYPE_AS_PER_RFI, delta]])
    # prediction = ml.regressor_SITE_RUN.predict([INFRATELID, CIRCLE, CLUSTER, ZONE, BILLING_OPCO, Site_TYPE,MONTH,delta])
    print(prediction)
    result['START_BB_RUN'] = prediction

    # regressor_END_BB_RUN
    prediction = ml.regressor_END_BB_RUN.predict([[Infraid, Circle, Cluster, Zone, BILLING_OPCO, SITE_TYPE_AS_PER_RFI, delta]])
    # prediction = ml.regressor_SITE_RUN.predict([INFRATELID, CIRCLE, CLUSTER, ZONE, BILLING_OPCO, Site_TYPE,MONTH,delta])
    print(prediction)
    result['END_BB_RUN'] = prediction

    # regressor_START_DG_KWH
    prediction = ml.regressor_START_DG_KWH.predict(
        [[Infraid, Circle, Cluster, Zone, BILLING_OPCO, SITE_TYPE_AS_PER_RFI, delta]])
    # prediction = ml.regressor_SITE_RUN.predict([INFRATELID, CIRCLE, CLUSTER, ZONE, BILLING_OPCO, Site_TYPE,MONTH,delta])
    print(prediction)
    result['START_DG_KWH'] = prediction

    # regressor_END_DG_KWH
    prediction = ml.regressor_END_DG_KWH.predict([[Infraid, Circle, Cluster, Zone, BILLING_OPCO, SITE_TYPE_AS_PER_RFI, delta]])
    # prediction = ml.regressor_SITE_RUN.predict([INFRATELID, CIRCLE, CLUSTER, ZONE, BILLING_OPCO, Site_TYPE,MONTH,delta])
    print(prediction)
    result['END_DG_KWH'] = prediction

    # regressor_START_EB_KWH
    prediction = ml.regressor_START_EB_KWH.predict(
        [[Infraid, Circle, Cluster, Zone, BILLING_OPCO, SITE_TYPE_AS_PER_RFI, delta]])
    # prediction = ml.regressor_SITE_RUN.predict([INFRATELID, CIRCLE, CLUSTER, ZONE, BILLING_OPCO, Site_TYPE,MONTH,delta])
    print(prediction)
    result['START_EB_KWH'] = prediction

    # regressor_END_EB_KWH
    prediction = ml.regressor_END_EB_KWH.predict([[Infraid, Circle, Cluster, Zone, BILLING_OPCO, SITE_TYPE_AS_PER_RFI, delta]])
    # prediction = ml.regressor_SITE_RUN.predict([INFRATELID, CIRCLE, CLUSTER, ZONE, BILLING_OPCO, Site_TYPE,MONTH,delta])
    print(prediction)
    result['END_EB_KWH'] = prediction

    return render_template("result.html", result=result)


app.run(port=5000, host='0.0.0.0')