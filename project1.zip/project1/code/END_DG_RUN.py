# 3. Building the model of END_DG_RUN
from yellowbrick.regressor import PredictionError

import database_data_importer as dbi
# 1. Building the model of SITE_RUN
x = dbi.x
a = dbi.a
def END_DG_RUN(x,a):
    from sklearn.model_selection import train_test_split
    return train_test_split(x, a, test_size=0.2, random_state=123456)

def model_END_DG_RUN(x_train, a_train):
    from sklearn.neighbors import KNeighborsRegressor
    regression = KNeighborsRegressor()
    return regression.fit(x_train, a_train)

def cross_validate_END_DG_RUN(algorithm, regression, x_test, a_test):
    predictions = regression.predict(x_test)
    return predictions
#
def visualization_error_END_DG_RUN(algorithm, regression, x_test, a_test):
    visualizer = PredictionError(regression)
    visualizer.fit(x_test, a_train)
    visualizer.score(x_test, a_test)
    return visualizer.show()

## 3.a END_DG_RUN_MODEL
x_train, x_test, a_train, a_test = END_DG_RUN(x,a)

