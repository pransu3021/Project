import numpy as np
import pandas as pd
import mysql.connector
from datetime import date

from yellowbrick.datasets import load_concrete
from yellowbrick.regressor import PredictionError


# Setup MySQL connection

def load_and_clean_data():
    db = mysql.connector.connect(host='localhost',
                                 database='project',
                                 user='cdac_project',
                                 password='cdac_project')

    # You must create a Cursor object. It will let you execute all the queries you need
    cur = db.cursor()

    # Use all the SQL you like
    # cur.execute("SELECT * FROM Report where INFRATELID = 'UWRT17016' ")
    # cur.execute( "SELECT INFRATELID, TENANTID, CIRCLE, CLUSTER, ZONE, BILLING_OPCO, OPCOS_NOC, SHARED_TYPE, CAST(LAST_COMMUNICATION as Date) as LAST_COMMUNICATION, DAYBEFORE_STATUS, STATUS_MTD, TOTAL_DAYS, COMM_STATUS, DCEM_STATUS, RUN_STATUS, ALL_3_KPI, CAST(START_DATE as Date) as START_DATE, CAST(END_DATE as Date) as END_DATE, SITE_RUN, START_DG_RUN, END_DG_RUN, START_EB_RUN, END_EB_RUN, START_BB_RUN, END_BB_RUN, START_DG_KWH, END_DG_KWH, START_EB_KWH, END_EB_KWH, DG_AVG_RUN, EB_AVG_RUN, BB_AVG_RUN FROM Report   where INFRATELID = 'ASGT10249' limit 10")
    cur.execute("SELECT INFRATELID,CIRCLE, CLUSTER, ZONE, BILLING_OPCO,SHARED_TYPE, DATEDIFF(END_Date, Start_Date), SITE_RUN, START_DG_RUN, END_DG_RUN, START_BB_RUN, END_EB_RUN, START_BB_RUN, END_BB_RUN,START_DG_KWH, END_DG_KWH, START_EB_KWH, END_EB_KWH from Report where INFRATELID = 'ASGT10249'")

    # Put it all to a data frame
    df = pd.DataFrame(cur.fetchall())
    df.columns = cur.column_names

    # Close the session

    # x = df.iloc[:, [0, 1, 2, 3, 4, 5, 6, 7]].values
    x = df.iloc[:, [0, 1, 2, 3, 4, 5, 6]].values
    # print(x)
    # x = df.iloc[:, [0, 2, 3, 4, 5, 7]].values

    # y = df.iloc[:, 8].values
    # z = df.iloc[:, 9].values
    # a = df.iloc[:, 10].values
    # b = df.iloc[:, 11].values
    # c = df.iloc[:, 12].values
    # d = df.iloc[:, 13].values
    # e = df.iloc[:, 14].values
    # f = df.iloc[:, 15].values
    # g = df.iloc[:, 16].values
    # h = df.iloc[:, 17].values
    # i = df.iloc[:, 18].values

    y = df.iloc[:, 7].values
    z = df.iloc[:, 8].values
    a = df.iloc[:, 9].values
    b = df.iloc[:, 10].values
    c = df.iloc[:, 11].values
    d = df.iloc[:, 12].values
    e = df.iloc[:, 13].values
    f = df.iloc[:, 14].values
    g = df.iloc[:, 15].values
    h = df.iloc[:, 16].values
    i = df.iloc[:, 17].values

    # SITE_RUN        ok    y
    # START_DG_RUN    ok    z
    # END_DG_RUN      ok    a
    # START_EB_RUN    ok    b
    # END_EB_RUN      ok    c
    # START_BB_RUN    ok    d
    # END_BB_RUN      ok    e
    # START_DG_KWH    ok    f
    # END_DG_KWH      ok    g
    # START_EB_KWH    ok    h
    # END_EB_KWH      ok    i

    from sklearn.preprocessing import LabelEncoder
    encoder = LabelEncoder()

    # 0: INFRATELID
    x[:, 0] = encoder.fit_transform(x[:, 0])

    # 1: CIRCLE
    x[:, 1] = encoder.fit_transform(x[:, 1])

    # 2: CLUSTER
    x[:, 2] = encoder.fit_transform(x[:, 2])

    # 3: zone
    x[:, 3] = encoder.fit_transform(x[:, 3])

    # 4: Billing_Opco
    x[:, 4] = encoder.fit_transform(x[:, 4])

    # 5: Shared_Type
    x[:, 5] = encoder.fit_transform(x[:, 5])

    # 6: MONTH
    # x[:, 6] = encoder.fit_transform(x[:, 6])

    cur.close()
    db.close()
    return x, y, z, a, b, c, d, e, f, g, h, i

#Loading the data
x, y, z, a, b, c, d, e, f, g, h, i= load_and_clean_data()
