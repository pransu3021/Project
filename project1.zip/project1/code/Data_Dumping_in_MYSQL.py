import mysql.connector
import csv
con = mysql.connector.connect(user = 'project_cdac', password= 'project_cdac', host='localhost', database = 'project1')
cur = con.cursor()
print("DataBase Connected")

csv_data = csv.reader(open("ab.csv"))

for row in csv_data:
    cur.execute('INSERT INTO assign (API,BasePrice,CREATIONDATE,CREATIONDATETIME,DealerCode,DealerName,DistChannel,Division,GroPrice,InvoiceDate,InvoiceNor,MRP,MaterialDescription,MaterialGrp2,MaterialNumber,Month,NSP,OfficerName,Officercode,OrderCreationdate,QTY,RSOCode,Region,SalesOfficeCode,SuppPLname,SuppPlant,Tax,Year) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)', row)


con.commit()

cur.close()
print("Done")




