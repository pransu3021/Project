from yellowbrick.regressor import PredictionError

import database_data_importer as dbi
# 1. Building the model of SITE_RUN
x = dbi.x
c = dbi.c

def END_EB_RUN(x,c):
    from sklearn.model_selection import train_test_split
    return train_test_split(x, c, test_size=0.2, random_state=123456)

def model_END_EB_RUN(x_train, c_train):
    from sklearn.neighbors import KNeighborsRegressor
    regression = KNeighborsRegressor()
    return regression.fit(x_train, c_train)

def cross_validate_END_EB_RUN(algorithm, regression, x_test, c_test):
    predictions = regression.predict(x_test)
    return predictions

def visualization_error_END_EB_RUN(algorithm, regression, x_test, c_test):
    visualizer = PredictionError(regression)
    visualizer.fit(x_test, c_train)
    visualizer.score(x_test, c_test)
    return visualizer.show()

## 5.a START_EB_RUN_MOdel
x_train, x_test, c_train, c_test = END_EB_RUN(x,c)