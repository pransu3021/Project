from yellowbrick.regressor import PredictionError

import SITE_RUN as SR
import START_DG_RUN as SDR
import  END_DG_RUN as EDR
import  START_EB_RUN as SER
import END_EB_RUN as EER
import START_BB_RUN as SBR
import END_BB_RUN as EBR
import START_DG_KWH as SDK
import END_DG_KWH as EDK
import START_EB_KWH as SEK
import END_EB_KWH as EEK
x_train = SR.x_train
x_test = SR.x_test
y_train = SR.y_train
y_test = SR.y_test
z_train = SDR.z_train
z_test = SDR.z_test
a_train = EDR.a_train
a_test = EDR.a_test
b_train = SER.b_train
b_test = SER.b_test
c_train = EER.c_train
c_test = EER.c_test
d_train = SBR.d_train
d_test = SBR.d_test
e_train = EBR.e_train
e_test = EBR.e_test
f_train = SDK.f_train
f_test = SDK.f_test
g_train = EDK.g_train
g_test = EDK.g_test
h_train = SEK.h_train
h_test = SEK.h_test
i_train = EEK.i_train
i_test = EEK.i_test

# x_train, x_test, y_train, y_test = SR.SITE_RUN(x,y)
#
print("Model is model_SITE_RUN")
print(y_test)
regressor_SITE_RUN = SR.model_SITE_RUN(x_train, y_train)
SITE_RUN_prediction_SITE_RUN = SR.cross_validate_SITE_RUN('SITE_RUN', regressor_SITE_RUN, x_test, y_test)
print(SITE_RUN_prediction_SITE_RUN)
# SITE_RUN_visualization = SR.visualization_error_SITE_RUN('SITE_RUN', regressor_SITE_RUN, x_test, y_test)



print("Model is model_START_DG_RUN")
print(z_test)
regressor_START_DG_RUN = SDR.model_START_DG_RUN(x_train, z_train)
START_DG_RUN_prediction_START_DG_RUN = SDR.cross_validate_START_DG_RUN('START_DG_RUN', regressor_START_DG_RUN, x_test, z_test)
print(START_DG_RUN_prediction_START_DG_RUN)
# START_DG_RUN_visualization = SDR.visualization_error_START_DG_RUN('START_DG_RUN', regressor_START_DG_RUN, x_test, z_test)


print("Model is model_END_DG_RUN")
print(a_test)
regressor_END_DG_RUN = EDR.model_END_DG_RUN(x_train, a_train)
END_DG_RUN_prediction_END_DG_RUN = EDR.cross_validate_END_DG_RUN('END_DG_RUN', regressor_END_DG_RUN, x_test, a_test)
print(END_DG_RUN_prediction_END_DG_RUN)
# END_DG_RUN_visualization = EDR.visualization_error_END_DG_RUN('END_DG_RUN', regressor_END_DG_RUN, x_test, a_test)


print("Model is model_START_EB_RUN")
print(b_test)
regressor_START_EB_RUN= SER.model_START_EB_RUN(x_train, b_train)
START_EB_RUN_prediction_START_EB_RUN = SER.cross_validate_START_EB_RUN('START_EB_RUN', regressor_START_EB_RUN, x_test, b_test)
print(START_EB_RUN_prediction_START_EB_RUN)
# START_EB_RUN_visualization = SER.visualization_error_START_EB_RUN('START_EB_RUN', regressor_START_EB_RUN, x_test, b_test)

print("Model is model_END_EB_RUN")
print(c_test)
regressor_END_EB_RUN= EER.model_END_EB_RUN(x_train, c_train)
END_EB_RUN_prediction_END_EB_RUN = EER.cross_validate_END_EB_RUN('END_EB_RUN', regressor_END_EB_RUN, x_test, c_test)
print(END_EB_RUN_prediction_END_EB_RUN)
# END_EB_RUN_visualization = EER.visualization_error_END_EB_RUN('END_BB_RUN', regressor_END_EB_RUN, x_test, c_test)

print("Model is model_START_BB_RUN")
print(d_test)
regressor_START_BB_RUN= SBR.model_START_BB_RUN(x_train, d_train)
START_BB_RUN_prediction_START_BB_RUN = SBR.cross_validate_START_BB_RUN('START_BB_RUN', regressor_START_BB_RUN, x_test, d_test)
print(START_BB_RUN_prediction_START_BB_RUN)
# START_BB_RUN_visualization = SBR.visualization_error_START_BB_RUN('END_BB_RUN', regressor_START_BB_RUN, x_test, d_test)

print("Model is model_END_BB_RUN")
print(e_test)
regressor_END_BB_RUN= EBR.model_END_BB_RUN(x_train, e_train)
END_BB_RUN_prediction_END_BB_RUN = EBR.cross_validate_END_BB_RUN('END_BB_RUN', regressor_END_BB_RUN, x_test, e_test)
print(END_BB_RUN_prediction_END_BB_RUN)
# END_BB_RUN_visualization = EBR.visualization_error_END_BB_RUN('END_BB_RUN', regressor_END_BB_RUN, x_test, e_test)


print("Model is model_START_DG_KWH")
print(f_test)
regressor_START_DG_KWH = SDK.model_START_DG_KWH(x_train, f_train)
START_DG_KWH_prediction_START_DG_KWH = SDK.cross_validate_START_DG_KWH('START_DG_KWH', regressor_START_DG_KWH, x_test, f_test)
print(START_DG_KWH_prediction_START_DG_KWH)
# START_DG_KWH_visualization = SDK.visualization_error_START_DG_KWH('START_DG_KWH', regressor_START_DG_KWH, x_test, f_test)

print("Model is model_END_DG_KWH")
print(g_test)
regressor_END_DG_KWH = EDK.model_END_DG_KWH(x_train, g_train)
END_DG_KWH_prediction_END_DG_KWH = EDK.cross_validate_END_DG_KWH('END_DG_KWH', regressor_END_DG_KWH, x_test, g_test)
print(END_DG_KWH_prediction_END_DG_KWH)
# END_DG_KWH_visualization = EDK.visualization_error_END_DG_KWH('END_DG_KWH', regressor_END_DG_KWH, x_test, g_test)
#
#
#
print("Model is model_START_EB_KWH")
print(h_test)
regressor_START_EB_KWH = SEK.model_START_EB_KWH(x_train, h_train)
START_EB_KWH_prediction_START_EB_KWH = SEK.cross_validate_START_EB_KWH('START_EB_KWH', regressor_START_EB_KWH, x_test, h_test)
print(START_EB_KWH_prediction_START_EB_KWH)
# START_EB_KWH_visualization = SEK.visualization_error_START_EB_KWH('START_EB_KWH', regressor_START_EB_KWH, x_test, h_test)

print("Model is model_END_EB_KWH")
print(i_test)
regressor_END_EB_KWH = EEK.model_END_EB_KWH(x_train, i_train)
END_EB_KWH_prediction_END_EB_KWH = EEK.cross_validate_END_EB_KWH('END_EB_KWH', regressor_END_EB_KWH, x_test, i_test)
print(END_EB_KWH_prediction_END_EB_KWH)
# END_EB_KWH_visualization = EEK.visualization_error_END_EB_KWH('END_EB_KWH', regressor_END_EB_KWH, x_test, i_test)