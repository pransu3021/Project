import mysql.connector

con = mysql.connector.connect(username = 'cdac_project', passwd= 'cdac_project', host='localhost', database = 'project')
cur = con.cursor()

# 1. END_BB_RUN
sql = 'SELECT INFRATELID, AVG(END_BB_RUN) from Report where END_BB_RUN is not null group by INFRATELID'
cur.execute(sql)
res = cur.fetchall()
dic = {}
for val in res:
    dic[val[0]] = val[1]
    # print(dic[val[0]])
for key_pair in dic:
    sql2 = f'UPDATE Report SET END_BB_RUN = {dic[key_pair]} WHERE END_BB_RUN IS NULL and INFRATELID = "{key_pair}"'
    print(sql2)
    print("ID updated")
    cur.execute(sql2)
    con.commit()
print('Updated complete column of END_BB_RUN')


# 2. START_DG_KWH
sql = 'SELECT INFRATELID, AVG(START_DG_KWH) from Report where START_DG_KWH is not null group by INFRATELID'
cur.execute(sql)
res = cur.fetchall()
dic = {}
for val in res:
    dic[val[0]] = val[1]
    # print(dic[val[0]])
for key_pair in dic:
    sql2 = f'UPDATE Report SET START_DG_KWH = {dic[key_pair]} WHERE START_DG_KWH IS NULL and INFRATELID = "{key_pair}"'
    print(sql2)
    print("ID updated")
    cur.execute(sql2)
    con.commit()
print('Updated complete column of START_DG_KWH')

#3. END_DG_KWH
sql = 'SELECT INFRATELID, AVG(END_DG_KWH) from Report where END_DG_KWH is not null group by INFRATELID'
cur.execute(sql)
res = cur.fetchall()
dic = {}
for val in res:
    dic[val[0]] = val[1]
    # print(dic[val[0]])
for key_pair in dic:
    sql2 = f'UPDATE Report SET END_DG_KWH = {dic[key_pair]} WHERE END_DG_KWH IS NULL and INFRATELID = "{key_pair}"'
    print(sql2)
    print("ID updated")
    cur.execute(sql2)
    con.commit()
print('Updated complete column of END_DG_KWH')

# 4. START_EB_KWH
sql = 'SELECT INFRATELID, AVG(START_EB_KWH) from Report where START_EB_KWH is not null group by INFRATELID'
cur.execute(sql)
res = cur.fetchall()
dic = {}
for val in res:
    dic[val[0]] = val[1]
    # print(dic[val[0]])
for key_pair in dic:
    sql2 = f'UPDATE Report SET START_EB_KWH = {dic[key_pair]} WHERE START_EB_KWH IS NULL and INFRATELID = "{key_pair}"'
    print(sql2)
    print("ID updated")
    cur.execute(sql2)
    con.commit()
print('Updated complete column of START_EB_KWH')


# 5. END_EB_KWH
sql = 'SELECT INFRATELID, AVG(END_EB_KWH) from Report where END_EB_KWH is not null group by INFRATELID'
cur.execute(sql)
res = cur.fetchall()
dic = {}
for val in res:
    dic[val[0]] = val[1]
    # print(dic[val[0]])


for key_pair in dic:
    sql2 = f'UPDATE Report SET END_EB_KWH = {dic[key_pair]} WHERE END_EB_KWH IS NULL and INFRATELID = "{key_pair}"'
    print(sql2)
    print("ID updated")
    cur.execute(sql2)
    con.commit()
print('Updated complete column of END_EB_KWH')

