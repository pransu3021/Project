from yellowbrick.regressor import PredictionError

import database_data_importer as dbi
# 1. Building the model of SITE_RUN
x = dbi.x
e = dbi.e

def END_BB_RUN(x,e):
    from sklearn.model_selection import train_test_split
    return train_test_split(x, e, test_size=0.2, random_state=123456)

def model_END_BB_RUN(x_train, e_train):
    from sklearn.neighbors import KNeighborsRegressor
    regression = KNeighborsRegressor()
    return regression.fit(x_train, e_train)

def cross_validate_END_BB_RUN(algorithm, regression, x_test, e_test):
    predictions = regression.predict(x_test)
    return predictions

def visualization_error_END_BB_RUN(algorithm, regression, x_test, e_test):
    visualizer = PredictionError(regression)
    visualizer.fit(x_test, e_train)
    visualizer.score(x_test, e_test)
    return visualizer.show()

x_train, x_test, e_train, e_test = END_BB_RUN(x,e)