from yellowbrick.regressor import PredictionError

import database_data_importer as dbi
# 1. Building the model of SITE_RUN
x = dbi.x
i = dbi.i

def END_EB_KWH(x,i):
    from sklearn.model_selection import train_test_split
    return train_test_split(x, i, test_size=0.2, random_state=123456)

def model_END_EB_KWH(x_train, i_train):
    from sklearn.neighbors import KNeighborsRegressor
    regression = KNeighborsRegressor()
    return regression.fit(x_train, i_train)

def cross_validate_END_EB_KWH(algorithm, regression, x_test, i_test):
    predictions = regression.predict(x_test)
    return predictions

def visualization_error_END_EB_KWH(algorithm, regression, x_test, i_test):
    visualizer = PredictionError(regression)
    visualizer.fit(x_test, i_train)
    visualizer.score(x_test, i_test)
    return visualizer.show()

##11.a END_EB_KWH_MODEL
x_train, x_test, i_train, i_test = END_EB_KWH(x,i)