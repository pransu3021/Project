from yellowbrick.regressor import PredictionError

import database_data_importer as dbi
# 1. Building the model of SITE_RUN
x = dbi.x
d = dbi.d


def START_BB_RUN(x,d):
    from sklearn.model_selection import train_test_split
    return train_test_split(x, d, test_size=0.2, random_state=123456)

def model_START_BB_RUN(x_train, d_train):
    from sklearn.neighbors import KNeighborsRegressor
    regression = KNeighborsRegressor()
    return regression.fit(x_train, d_train)

def cross_validate_START_BB_RUN(algorithm, regression, x_test, d_test):
    predictions = regression.predict(x_test)
    return predictions

def visualization_error_START_BB_RUN(algorithm, regression, x_test, d_test):
    visualizer = PredictionError(regression)
    visualizer.fit(x_test, d_train)
    visualizer.score(x_test, d_test)
    return visualizer.show()

## 6.a START_START_EB_RUN
x_train, x_test, d_train, d_test = START_BB_RUN(x,d)